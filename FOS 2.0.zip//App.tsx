import React, { useState } from 'react';

// Define types for better code structure
type Feature =
  | 'dashboard'
  | 'cycle_tracker'
  | 'ovulation_predictor'
  | 'sperm_analysis'
  | 'clinic_finder'
  | 'resources'
  | 'community'
  | 'appointments'
  | 'telehealth'
  | 'genetics'
  | 'wellness';

interface FeatureConfig {
  id: Feature;
  name: string;
  description: string;
  icon: JSX.Element; // Placeholder for icon
  genderTarget: 'all' | 'female' | 'male';
}

// Placeholder Icon Component
const FeatureIcon = () => <div className="bg-blue-100 border border-blue-200 rounded-md w-6 h-6 mr-3"></div>;
const PlaceholderImage = () => <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-48 flex items-center justify-center text-gray-500">Placeholder Image</div>;
const PlaceholderContent = ({ title }: { title: string }) => (
    <div className="p-6 bg-white rounded-lg shadow">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">{title}</h2>
        <p className="text-gray-600 mb-4">Detailed information and interactive elements for the {title.toLowerCase()} feature would be displayed here.</p>
        <PlaceholderImage />
    </div>
);


const FertilitySuperApp: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<Feature>('dashboard');

  const features: FeatureConfig[] = [
    { id: 'dashboard', name: 'Dashboard', description: 'Overview of your journey', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'cycle_tracker', name: 'Cycle Tracker', description: 'Log and predict cycles', icon: <FeatureIcon />, genderTarget: 'female' },
    { id: 'ovulation_predictor', name: 'Ovulation Predictor', description: 'Identify fertile window', icon: <FeatureIcon />, genderTarget: 'female' },
    { id: 'sperm_analysis', name: 'Sperm Analysis Info', description: 'Understand male fertility', icon: <FeatureIcon />, genderTarget: 'male' },
    { id: 'clinic_finder', name: 'Clinic Finder', description: 'Locate fertility specialists', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'resources', name: 'Resources', description: 'Articles and guides', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'community', name: 'Community', description: 'Connect with others', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'appointments', name: 'Appointments', description: 'Manage visits', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'telehealth', name: 'Telehealth', description: 'Virtual consultations', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'genetics', name: 'Genetic Testing', description: 'Information on tests', icon: <FeatureIcon />, genderTarget: 'all' },
    { id: 'wellness', name: 'Wellness Tips', description: 'Lifestyle advice', icon: <FeatureIcon />, genderTarget: 'all' },
  ];

  const renderContent = () => {
    const selectedFeature = features.find(f => f.id === activeFeature);
    const title = selectedFeature ? selectedFeature.name : 'Welcome';

    switch (activeFeature) {
      case 'dashboard':
        return (
          <div className="p-6 bg-white rounded-lg shadow space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Welcome to Your Fertility Dashboard</h2>
            <p className="text-gray-600">Here's a summary of your current status and quick access to key features.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
               {/* Example Summary Cards */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-2">Cycle Status</h3>
                <p className="text-sm text-blue-700">Day 15 - Fertile Window (Estimated)</p>
                 <div className="mt-2 h-2 w-full bg-blue-200 rounded-full"><div className="h-2 bg-blue-500 rounded-full w-1/2"></div></div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-semibold text-green-800 mb-2">Next Appointment</h3>
                <p className="text-sm text-green-700">Dr. Smith - July 25th, 10:00 AM</p>
                 <button className="mt-2 text-sm text-green-600 hover:text-green-800">View Details</button>
              </div>
               <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <h3 className="font-semibold text-purple-800 mb-2">Wellness Tip</h3>
                <p className="text-sm text-purple-700">Remember to stay hydrated and manage stress.</p>
                <button className="mt-2 text-sm text-purple-600 hover:text-purple-800">Learn More</button>
              </div>
            </div>
            <PlaceholderImage />
          </div>
        );
      case 'cycle_tracker':
        return <PlaceholderContent title="Cycle Tracker" />;
      case 'ovulation_predictor':
        return <PlaceholderContent title="Ovulation Predictor" />;
      case 'sperm_analysis':
         return <PlaceholderContent title="Sperm Analysis Info" />;
      case 'clinic_finder':
         return <PlaceholderContent title="Clinic Finder" />;
       case 'resources':
         return <PlaceholderContent title="Educational Resources" />;
       case 'community':
         return <PlaceholderContent title="Community Forum" />;
      case 'appointments':
         return <PlaceholderContent title="Appointments" />;
      case 'telehealth':
          return <PlaceholderContent title="Telehealth Consultation" />;
      case 'genetics':
          return <PlaceholderContent title="Genetic Testing Info" />;
       case 'wellness':
          return <PlaceholderContent title="Wellness & Lifestyle" />;
      default:
        return <PlaceholderContent title="Feature Not Found" />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white shadow-md flex flex-col p-4">
        <div className="mb-6 flex items-center pl-2">
           <div className="bg-blue-500 rounded-full w-8 h-8 mr-2"></div> {/* App Logo Placeholder */}
          <h1 className="text-xl font-bold text-gray-800">FertilityApp</h1>
        </div>
        <nav className="flex-grow space-y-1 overflow-y-auto">
          {features.map((feature) => (
            <button
              key={feature.id}
              onClick={() => setActiveFeature(feature.id)}
              className={`w-full flex items-center px-3 py-2 rounded-md text-sm font-medium text-left transition-colors duration-150 ease-in-out ${
                activeFeature === feature.id
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              {feature.icon}
              {feature.name}
            </button>
          ))}
        </nav>
        <div className="mt-auto pt-4 border-t border-gray-200">
             {/* User Profile Placeholder */}
            <div className="flex items-center p-2 rounded-md hover:bg-gray-50 cursor-pointer">
                 <div className="bg-gray-300 rounded-full w-8 h-8 mr-3"></div>
                 <div>
                     <p className="text-sm font-medium text-gray-800">User Name</p>
                     <p className="text-xs text-gray-500">View Profile</p>
                 </div>
            </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
};

export default FertilitySuperApp;