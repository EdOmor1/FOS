import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Dummy data for cycle chart
const cycleData = [
  { day: 'Day 1', lh: 5, estrogen: 50 },
  { day: 'Day 5', lh: 6, estrogen: 70 },
  { day: 'Day 9', lh: 8, estrogen: 150 },
  { day: 'Day 12', lh: 40, estrogen: 300 }, // LH Surge
  { day: 'Day 14', lh: 10, estrogen: 200 }, // Ovulation
  { day: 'Day 18', lh: 7, estrogen: 180 },
  { day: 'Day 22', lh: 6, estrogen: 150 },
  { day: 'Day 26', lh: 5, estrogen: 100 },
];

// Dummy data for sperm health
const spermHealthData = {
    count: 60, // million/mL
    motility: 55, // %
    morphology: 5, // %
    lastAnalysisDate: '2024-06-15',
};

// Dummy data for IVF journey
const ivfJourneyData = {
    currentStage: 'Stimulation',
    nextAppointment: 'Follicle Check Ultrasound',
    nextAppointmentDate: '2024-07-28',
    medications: ['Gonal-F', 'Menopur', 'Cetrotide'],
};

// Dummy data for community
const communityPosts = [
    { id: 1, title: 'Tips for managing IVF stress?', forum: 'IVF Support', replies: 15 },
    { id: 2, title: 'Anyone else tracking BBT with PCOS?', forum: 'TTC Naturally', replies: 8 },
    { id: 3, title: 'Good RE recommendations in NYC?', forum: 'Clinic Reviews', replies: 22 },
];

// Type definitions for state clarity
type ActiveSection = 'dashboard' | 'tracker' | 'journey' | 'marketplace' | 'finances' | 'community' | 'profile';
type UserType = 'female' | 'male' | 'couple' | null; // Example user types

interface FertilityAppData {
    fertilityScore: number;
    aiInsights: string[];
    upcomingTasks: { id: number, text: string, due: string }[];
}

export default function FertilitySuperAppDashboard() {
    const [activeSection, setActiveSection] = useState<ActiveSection>('dashboard');
    const [userType, setUserType] = useState<UserType>(null); // Simulate onboarding choice
    const [showAIAssistant, setShowAIAssistant] = useState<boolean>(false);
    const [aiQuery, setAiQuery] = useState<string>('');
    const [aiResponse, setAiResponse] = useState<string>('');
    const [appData, setAppData] = useState<FertilityAppData | null>(null);

    // Simulate fetching initial data and user type determination
    useEffect(() => {
        // In a real app, this would fetch data based on logged-in user
        const timer = setTimeout(() => {
            // Simulate choosing user type after a delay
             const randomType = Math.random();
             if (randomType < 0.4) setUserType('female');
             else if (randomType < 0.8) setUserType('couple');
             else setUserType('male');

             setAppData({
                 fertilityScore: Math.floor(Math.random() * 50) + 50, // Score between 50-100
                 aiInsights: [
                     'Consider adding CoQ10 to your supplement plan based on recent data.',
                     'Your predicted fertile window starts in 3 days.',
                     'Slight decrease in sperm motility noted, review dietary factors.',
                 ],
                 upcomingTasks: [
                     { id: 1, text: 'Log Cycle Day 1 symptoms', due: 'Today' },
                     { id: 2, text: 'Take prenatal vitamins', due: 'Daily' },
                     { id: 3, text: `Dr. Smith Appointment`, due: '2024-07-30' },
                     { id: 4, text: `Renew cryo storage plan`, due: '2024-08-15' },
                 ],
             });

        }, 1500); // Simulate loading time and onboarding
        return () => clearTimeout(timer);
    }, []);

    const handleAiQuery = () => {
        setAiResponse(`AI Response: Based on your query "${aiQuery}", here's personalized information... [Details would follow]`);
        // Reset query for demo purposes
        // setAiQuery('');
    };

    const renderSectionContent = () => {
        switch (activeSection) {
            case 'dashboard':
                return <DashboardContent />;
            case 'tracker':
                return <TrackerContent />;
            case 'journey':
                return <JourneyContent />;
            case 'marketplace':
                return <MarketplaceContent />;
            case 'finances':
                return <FinancesContent />;
            case 'community':
                return <CommunityContent />;
            case 'profile':
                return <ProfileContent />;
            default:
                return <DashboardContent />;
        }
    };

    const DashboardContent = () => (
        <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold text-gray-800">Welcome Back!</h2>
            {appData ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* Fertility Score & AI Insights */}
                    <div className="bg-white p-4 rounded-lg shadow col-span-1 md:col-span-2 lg:col-span-1">
                        <h3 className="font-semibold text-lg mb-2 text-indigo-700">Your Fertility Snapshot</h3>
                        <p className="text-gray-600 mb-1">Overall Fertility Score:</p>
                        <p className="text-3xl font-bold text-indigo-600 mb-3">{appData.fertilityScore}/100</p>
                        <h4 className="font-semibold text-md mb-1 text-gray-700">AI Insights:</h4>
                        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                            {appData.aiInsights.slice(0, 2).map((insight, index) => <li key={index}>{insight}</li>)}
                        </ul>
                         <button onClick={() => setShowAIAssistant(true)} className="mt-3 text-sm text-indigo-600 hover:text-indigo-800 font-medium">Ask FertilityIQ...</button>
                    </div>

                     {/* Today's Focus / Upcoming Tasks */}
                     <div className="bg-white p-4 rounded-lg shadow">
                        <h3 className="font-semibold text-lg mb-2 text-teal-700">Today's Focus</h3>
                        <ul className="space-y-2">
                            {appData.upcomingTasks.slice(0, 3).map(task => (
                                <li key={task.id} className="flex justify-between items-center text-sm">
                                    <span className="text-gray-700">{task.text}</span>
                                    <span className="text-xs font-medium text-teal-600 bg-teal-100 px-2 py-0.5 rounded-full">{task.due}</span>
                                </li>
                            ))}
                        </ul>
                        <button onClick={() => setActiveSection('journey')} className="mt-3 text-sm text-teal-600 hover:text-teal-800 font-medium">View Full Plan</button>
                    </div>

                     {/* Cycle / Sperm Tracker Summary */}
                    {(userType === 'female' || userType === 'couple') && (
                        <div className="bg-white p-4 rounded-lg shadow">
                             <h3 className="font-semibold text-lg mb-2 text-pink-700">Cycle Tracker</h3>
                             <p className="text-sm text-gray-600 mb-2">Predicted Ovulation: <span className="font-medium">~ Day 14</span></p>
                             <div className="h-32"> {/* Fixed height container for chart */}
                                <ResponsiveContainer width="100%" height="100%">
                                    <LineChart data={cycleData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                                        <XAxis dataKey="day" fontSize={10} />
                                        <YAxis fontSize={10} />
                                        <Tooltip wrapperClassName="text-xs" />
                                        <Line type="monotone" dataKey="lh" stroke="#e879f9" strokeWidth={2} dot={false} name="LH" />
                                        <Line type="monotone" dataKey="estrogen" stroke="#f472b6" strokeWidth={2} dot={false} name="Estrogen" />
                                    </LineChart>
                                </ResponsiveContainer>
                             </div>
                             <button onClick={() => setActiveSection('tracker')} className="mt-3 text-sm text-pink-600 hover:text-pink-800 font-medium">View Full Cycle</button>
                        </div>
                    )}
                     {(userType === 'male' || userType === 'couple') && (
                        <div className="bg-white p-4 rounded-lg shadow">
                             <h3 className="font-semibold text-lg mb-2 text-blue-700">Sperm Health</h3>
                             <p className="text-sm text-gray-600 mb-1">Last Analysis: {spermHealthData.lastAnalysisDate}</p>
                             <div className="flex justify-around text-center mt-2 text-sm">
                                 <div><p className="font-semibold text-blue-600">{spermHealthData.count} M/mL</p><p className="text-xs text-gray-500">Count</p></div>
                                 <div><p className="font-semibold text-blue-600">{spermHealthData.motility}%</p><p className="text-xs text-gray-500">Motility</p></div>
                                 <div><p className="font-semibold text-blue-600">{spermHealthData.morphology}%</p><p className="text-xs text-gray-500">Morphology</p></div>
                             </div>
                             <button onClick={() => setActiveSection('tracker')} className="mt-3 text-sm text-blue-600 hover:text-blue-800 font-medium">View Details & Tips</button>
                        </div>
                    )}

                    {/* Quick Actions */}
                    <div className="bg-white p-4 rounded-lg shadow col-span-1 md:col-span-2 lg:col-span-1">
                         <h3 className="font-semibold text-lg mb-3 text-gray-700">Quick Actions</h3>
                         <div className="space-y-2">
                             <button className="w-full text-left text-sm p-2 bg-indigo-50 hover:bg-indigo-100 rounded text-indigo-700">Order At-Home Test Kit</button>
                             <button onClick={() => setActiveSection('marketplace')} className="w-full text-left text-sm p-2 bg-teal-50 hover:bg-teal-100 rounded text-teal-700">Find a Clinic or Specialist</button>
                             <button onClick={() => setActiveSection('finances')} className="w-full text-left text-sm p-2 bg-pink-50 hover:bg-pink-100 rounded text-pink-700">Explore Financial Options</button>
                         </div>
                    </div>

                    {/* Community Hot Topics */}
                    <div className="bg-white p-4 rounded-lg shadow">
                        <h3 className="font-semibold text-lg mb-2 text-purple-700">Community Buzz</h3>
                        <ul className="space-y-2">
                            {communityPosts.slice(0, 2).map(post => (
                                <li key={post.id} className="text-sm border-b pb-1 border-gray-100">
                                    <p className="text-gray-800 hover:text-purple-600 cursor-pointer">{post.title}</p>
                                    <p className="text-xs text-gray-500">{post.forum} • {post.replies} replies</p>
                                </li>
                            ))}
                        </ul>
                         <button onClick={() => setActiveSection('community')} className="mt-3 text-sm text-purple-600 hover:text-purple-800 font-medium">Join Discussions</button>
                    </div>

                 </div>
            ) : (
                 <div className="flex justify-center items-center h-64">
                    <p className="text-gray-500">Loading your dashboard...</p>
                     {/* Basic spinner */}
                     <div className="ml-2 w-5 h-5 border-t-2 border-indigo-500 border-solid rounded-full animate-spin"></div>
                 </div>
            )}
        </div>
    );

    // Placeholder Content for other sections
    const TrackerContent = () => <div className="p-6"><h2 className="text-2xl font-semibold text-gray-800">Cycle & Sperm Health Tracker</h2><p className="text-gray-600 mt-2">Detailed tracking interface for periods, ovulation, hormones, symptoms, and sperm health parameters would be here. Integration with wearables (Apple Health, Oura, etc.) would display synced data.</p><div className="mt-4 p-4 border border-dashed rounded-lg bg-gray-50 h-64 flex items-center justify-center text-gray-400">Tracker Component Area</div></div>;
    const JourneyContent = () => <div className="p-6"><h2 className="text-2xl font-semibold text-gray-800">IVF/IUI Journey Manager</h2><p className="text-gray-600 mt-2">Timeline planning, cost tracking, medication schedules, document uploads, appointment syncing, and couple collaboration features would live here.</p><div className="mt-4 p-4 border border-dashed rounded-lg bg-gray-50 h-64 flex items-center justify-center text-gray-400">Journey Manager Component Area</div></div>;
    const MarketplaceContent = () => <div className="p-6"><h2 className="text-2xl font-semibold text-gray-800">Marketplace: Clinics, Coaches, Donors</h2><p className="text-gray-600 mt-2">Search, filter, and book vetted fertility experts, clinics, coaches, and access AI-powered donor matching. Includes reviews, pricing, and availability.</p><div className="mt-4 p-4 border border-dashed rounded-lg bg-gray-50 h-64 flex items-center justify-center text-gray-400">Marketplace Component Area</div></div>;
    const FinancesContent = () => <div className="p-6"><h2 className="text-2xl font-semibold text-gray-800">Financial Dashboard</h2><p className="text-gray-600 mt-2">Personalized cost estimates, tracking for expenses, integration with grants/insurance, savings calculator, and benefits eligibility checker.</p><div className="mt-4 p-4 border border-dashed rounded-lg bg-gray-50 h-64 flex items-center justify-center text-gray-400">Financial Tools Area</div></div>;
    const CommunityContent = () => <div className="p-6"><h2 className="text-2xl font-semibold text-gray-800">Community & Support</h2><p className="text-gray-600 mt-2">Private, moderated forums based on journey type (TTC, IVF, LGBTQ+, etc.), anonymous mode options, and matchmaking with therapists or coaches.</p><div className="mt-4 p-4 border border-dashed rounded-lg bg-gray-50 h-64 flex items-center justify-center text-gray-400">Community Forum Area</div></div>;
    const ProfileContent = () => <div className="p-6"><h2 className="text-2xl font-semibold text-gray-800">Profile & Settings</h2><p className="text-gray-600 mt-2">Manage personal details, linked accounts (wearables, clinics), notification preferences, subscription status, privacy settings, and access help/support.</p><div className="mt-4 p-4 border border-dashed rounded-lg bg-gray-50 h-64 flex items-center justify-center text-gray-400">User Profile & Settings Area</div></div>;


    // AI Assistant Modal/Overlay
    const AiAssistant = () => (
        <div className="fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-indigo-700">FertilityIQ Assistant</h3>
                    <button onClick={() => setShowAIAssistant(false)} className="text-gray-500 hover:text-gray-700">
                        {/* Simple X icon */}
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <p className="text-sm text-gray-600 mb-4">Ask anything about your fertility journey, test results, or treatment options.</p>
                <textarea
                    className="w-full p-2 border border-gray-300 rounded mb-3 h-24 text-sm focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="e.g., Explain my recent AMH results..."
                    value={aiQuery}
                    onChange={(e) => setAiQuery(e.target.value)}
                />
                <button
                    onClick={handleAiQuery}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded transition duration-150 ease-in-out"
                >
                    Ask AI
                </button>
                {aiResponse && (
                    <div className="mt-4 p-3 bg-indigo-50 rounded border border-indigo-200">
                        <p className="text-sm text-indigo-800">{aiResponse}</p>
                    </div>
                )}
            </div>
        </div>
    );


    // Main App Layout
    return (
        <div className="flex h-screen bg-gray-100 font-sans">
            {/* Sidebar Navigation */}
            <nav className="w-64 bg-white shadow-md flex flex-col">
                <div className="p-4 border-b border-gray-200">
                     {/* Placeholder Logo */}
                     <div className="flex items-center space-x-2">
                        <div className="bg-indigo-100 border-2 border-dashed border-indigo-300 rounded-xl w-10 h-10 flex items-center justify-center text-indigo-600 font-bold text-xl">
                            F+
                        </div>
                        <h1 className="text-xl font-bold text-indigo-800">FertilityOS</h1>
                     </div>
                </div>
                <ul className="flex-grow p-4 space-y-2">
                    {[
                        { name: 'Dashboard', section: 'dashboard' as ActiveSection, icon: '📊' },
                        { name: 'Tracker', section: 'tracker' as ActiveSection, icon: '🗓️' },
                        { name: 'Journey Plan', section: 'journey' as ActiveSection, icon: '🗺️' },
                        { name: 'Marketplace', section: 'marketplace' as ActiveSection, icon: '🏥' },
                        { name: 'Finances', section: 'finances' as ActiveSection, icon: '💰' },
                        { name: 'Community', section: 'community' as ActiveSection, icon: '💬' },
                    ].map(item => (
                        <li key={item.section}>
                            <button
                                onClick={() => setActiveSection(item.section)}
                                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition duration-150 ease-in-out ${
                                    activeSection === item.section
                                        ? 'bg-indigo-100 text-indigo-700'
                                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                                }`}
                            >
                                <span>{item.icon}</span>
                                <span>{item.name}</span>
                            </button>
                        </li>
                    ))}
                </ul>
                <div className="p-4 border-t border-gray-200">
                     <button
                        onClick={() => setActiveSection('profile')}
                         className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition duration-150 ease-in-out ${
                             activeSection === 'profile'
                                 ? 'bg-indigo-100 text-indigo-700'
                                 : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                         }`}
                    >
                         {/* Placeholder Avatar */}
                        <div className="bg-gray-200 border-2 border-dashed rounded-full w-6 h-6"></div>
                        <span>My Profile</span>
                    </button>
                     <button
                        onClick={() => setShowAIAssistant(true)}
                         className="mt-2 w-full flex items-center justify-center space-x-2 px-3 py-2 rounded-md text-sm font-medium bg-indigo-500 text-white hover:bg-indigo-600 transition duration-150 ease-in-out"
                    >
                        <span>💡</span>
                        <span>Ask FertilityIQ</span>
                    </button>
                </div>
            </nav>

            {/* Main Content Area */}
            <main className="flex-1 overflow-y-auto">
                {/* Optional Header within main content */}
                 <header className="bg-white shadow-sm p-4 border-b border-gray-200 sticky top-0 z-10 flex justify-between items-center">
                     <h2 className="text-xl font-semibold text-gray-700 capitalize">{activeSection}</h2>
                     {/* Placeholder for notifications or quick actions */}
                    <div className="flex items-center space-x-4">
                         <button className="text-gray-500 hover:text-gray-700">
                             {/* Bell Icon Placeholder */}
                             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                         </button>
                          <div className="bg-gray-200 border-2 border-dashed rounded-full w-8 h-8"></div>
                     </div>
                 </header>

                {/* Render active section */}
                {renderSectionContent()}
            </main>

            {/* AI Assistant Modal */}
            {showAIAssistant && <AiAssistant />}
        </div>
    );
}